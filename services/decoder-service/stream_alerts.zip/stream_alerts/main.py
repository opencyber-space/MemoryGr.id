from modules import listener
from modules import aios_logger


def main():
    logger = aios_logger.AIOSLogger()
    listener.start_listening(logger)

if __name__ == "__main__":
    main()

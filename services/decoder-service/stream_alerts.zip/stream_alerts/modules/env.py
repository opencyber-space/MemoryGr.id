import os


class Envs:

    def __init__(self):

        # local redis parameters
        self.redis_host = os.getenv("LOCAL_REDIS_HOST", "localhost")
        self.redis_port = os.getenv("LOCAL_REDIS_PORT", "6379")
        self.redis_password = os.getenv("LOCAL_REDIS_PASSWORD", None)
        self.redis_db = int(os.getenv("LOCAL_REDIS_DB", "0"))
        self.redis_queue_name = os.getenv("LOCAL_REDIS_QUEUE", "stream_alerts")

        self.source_registry_uri = os.getenv(
            "SOURCE_CONTROLLER_URI", "http://192.168.111.113:32000/sr"
        )

        self.enable_status_update = False
        self.redis_connect_retry_interval = 5

        self.alert_id_svc = os.getenv(
            "ALERT_ID_API", None
        )

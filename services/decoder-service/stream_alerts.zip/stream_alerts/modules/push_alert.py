import requests
import time

from .aios_logger import AIOSLogger, ErrorSeverity
from .env import Envs
from .tampering import push_alert


alert_history = {}


class AlertPusher:

    def __init__(self, env: Envs, sourceID, logger: AIOSLogger) -> None:
        self.sourceID = sourceID
        self.logger = logger
        self.env = env

    def get_source_info(self):
        try:
            URL = "{}/api/getBySourceID".format(self.env.source_registry_uri)
            payload = {
                "sourceID": self.sourceID
            }

            response = requests.post(URL, json=payload)
            if response.status_code != 200:
                st = response.status_code
                raise Exception("Server error, code={}".format(st))

            response = response.json()
            if response['error']:
                raise Exception(response['payload'])

            sources = response['payload']
            if len(sources) == 0:
                raise Exception(response['payload'])

            return True, sources[0]

        except Exception as e:
            print("Source Fetch: ", e)
            return False, e

    def prepare_parameters(self, sourceData, extra_data):

        # pepare a dict of parameters from the source data, keep fields empty if not found
        preparedData = {}
        preparedData['extraData'] = extra_data

        # 1. source URL or file-path
        if sourceData['sourceType'] == "live":
            url = sourceData.get("liveSourceInfo", {}).get(
                "streamURL", "unknown")
            preparedData["cameraIP"] = url

            # geo-json parameters
            geo = sourceData.get("liveSourceInfo", {}).get("geoJson", {})
            preparedData['geoJson'] = {
                "lat": geo.get("lat", 0.0),
                "long": geo.get("long", 0.0)
            }
            preparedData['location'] = sourceData.get("label", "unknown")

        else:
            url = sourceData.get("offlineVideo", {}).get(
                "storageVideoPath", "unknown")
            preparedData["cameraIP"] = url
            preparedData['location'] = sourceData.get("label", "unknown")

        # get alerts from top-level dict:
        alertData = {}
        if 'alerts' in sourceData and sourceData['alerts'].get('enabled', False):
            alertData = sourceData['alerts']
        # 3. alert parameters:
        elif 'sourceMetadata' in sourceData:
            # return False, "No 'sourceMetadata' in source information", 0
            metadata = sourceData["sourceMetadata"].get("calibrationData", {})
            # alerts are enabled?
            if 'alerts' not in metadata or not metadata['alerts'].get('enabled', False):
                return False, "alerts are not enabled for this camera", 0
            alertData = metadata['alerts']
        else:
            return False, "No 'sourceMetadata' in source information", 0

        # get alert parameters:
        if 'eventType' in alertData:
            preparedData['eventType'] = 'cameraDisconnection' #alertData['eventType']
        if 'eventMessage' in alertData:
            preparedData['eventMessage'] = alertData['eventMessage']
        if 'severity' in alertData:
            preparedData['severity'] = alertData['severity']
        if 'minioParams' in alertData:
            preparedData['minioParams'] = alertData['minioParams']
        if 'mongoParams' in alertData:
            preparedData['mongoParams'] = alertData['mongoParams']
        if 'redisParams' in alertData:
            preparedData['redisParams'] = alertData['redisParams']
        if self.env.alert_id_svc:
            preparedData['alertURL'] = self.env.alert_id_svc

        return True, preparedData, int(alertData.get("alertInterval", 0))
    

    def can_allow(self, sourceID, interval):

        st = time.time()
        if sourceID not in alert_history:
            alert_history[sourceID] = st
            return True
        
        # can it be allowed?
        allowed = (st - alert_history[sourceID]) > interval
        if allowed:
            alert_history[sourceID] = st
        return allowed

    def push(self, extra_data={}):
        try:
            ret, data = self.get_source_info()
            if not ret:
                raise data

            ret, preparedData, interval = self.prepare_parameters(data, extra_data)
            if not ret:
                raise Exception("{}: {}".format(self.sourceID, preparedData))
            
            if not self.can_allow(self.sourceID, interval):
                raise Exception(
                    "alert for {} is not allowed because it is less than the interval {}s".format(
                        self.sourceID, interval
                    )
                )

            # set sourceID
            preparedData['cameraID'] = self.sourceID

            # push the alert:
            push_alert(**preparedData)

            self.logger.info(action="stream_alert_push", message="pushed alert for source {}".format(
                self.sourceID
            ), extras={})

        except Exception as e:
            self.logger.error(
                action="stream_alert_push",
                severity=ErrorSeverity.HIGH,
                message="stream alerts service failed because of {}".format(e),
                exception=e,
                extras={}
            )

import json
import redis
from pymongo import MongoClient
from datetime import timedelta
from minio.error import (ResponseError, BucketAlreadyOwnedByYou,
                         BucketAlreadyExists)
from minio import Minio
import sys
import os
import requests
import json
from datetime import datetime
import time


def getAlertID(eventType, ALERTIDURL):
    try:
        headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
        #url = "http://0.0.0.0:7002/getalertid"
        jsonData = {"eventType": eventType}
        resp = requests.get(ALERTIDURL, data=json.dumps(
            jsonData), headers=headers)  # ,verify=False)
        #print("getalertid resp:",str(resp))
        result = json.loads(resp.content.decode("utf-8"))
        if result["status"] == "Failed":
            raise Exception(result["statusMessage"])
        alertid = result["alertid"]
        return True, "", alertid
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        infoTolog = "ERROR! "+str(exc_type)+" getAlertID " + \
            str(fname)+" " + str(exc_tb.tb_lineno)
        del exc_type, exc_obj, exc_tb
        return False, infoTolog, ""


def timestampToDateTime(timestamp: float):
    timeStamp_str = time.strftime(
        '%Y-%m-%dT%H:%M:%S', time.localtime(timestamp))
    # get decimal and attach to str for 6 digit
    timeStamp_str = timeStamp_str+'.' + \
        format(timestamp % 1, '.6f').split("0.")[1]+'Z'
    timeStamp_obj = datetime.strptime(timeStamp_str, '%Y-%m-%dT%H:%M:%S.%fZ')
    return timeStamp_str, timeStamp_obj


# Import MinIO library.


class MinioUploader:
    def __init__(self, params: dict):
        self.minioClient = Minio(endpoint=params["endpoint"],
                                 access_key=params["access_key"],
                                 secret_key=params["secret_key"],
                                 secure=False)
        self.ALERTURLREPLACER = params["MINIOURLREPLACEMENT"]
        self.minioendpoint = "http://"+params["endpoint"]

    def forward(self, bucketName, fileName, filePath, deltaDays=2, content_type="image/jpeg"):
        # Make a bucket with the make_bucket API call.
        try:
            self.minioClient.make_bucket(bucketName)
        except BucketAlreadyOwnedByYou as err:
            print("In forward:BucketAlreadyOwnedByYou")
            try:
                print("In forward:Uploading")
                self.minioClient.fput_object(
                    bucketName, fileName, filePath, content_type=content_type)
                url = self.minioClient.presigned_get_object(
                    bucketName, fileName, expires=timedelta(days=deltaDays))
            except ResponseError as err:
                return False, str(err), ""
        except BucketAlreadyExists as err:
            print("In forward:BucketAlreadyExists")
            try:
                print("In forward:Uploading")
                self.minioClient.fput_object(
                    bucketName, fileName, filePath, content_type=content_type)
                url = self.minioClient.presigned_get_object(
                    bucketName, fileName, expires=timedelta(days=deltaDays))
            except ResponseError as err:
                return False, str(err), ""

        except ResponseError as err:
            return False, str(err), ""
        else:
            # Put an object 'pumaserver_debug.log' with contents from 'pumaserver_debug.log'.
            try:
                print("In forward:Uploading")
                self.minioClient.fput_object(
                    bucketName, fileName, filePath, content_type=content_type)
                url = self.minioClient.presigned_get_object(
                    bucketName, fileName, expires=timedelta(days=deltaDays))
            except ResponseError as err:
                return False, str(err), ""

        url = url.split(".jpg?")[0]+".jpg"
        if self.ALERTURLREPLACER:
            url = url.replace(self.minioendpoint, self.ALERTURLREPLACER)
        print("In forward:uploaded url:", url)
        return True, "", url


class MongoDBUtil:
    def __init__(self, params: dict):
        self.params = params
        if "mongodb://" in params["host"]:
            dbMongoStr = params["host"]
        else:
            dbMongoStr = 'mongodb://' + \
                str(params["host"]) + ':' + str(params["port"]) + '/'
        try:
            client = MongoClient(dbMongoStr)
            db = client[params["dbname"]]
            self.collection = db[params["collection"]]
            resp = self.collection.create_index([("timeStamp", -1)])
        except Exception as e:
            raise Exception("Could not connect to Mongo instance")

        #self.sessionID = sessionID
        self.initTime = time.time()

    def forward(self, eventType, eventMessage, severity, datetimeobj, imgURL, alertID, location, cameraID, cameraIP, data):
        try:
            mongoDBSaveDict = {}
            mongoDBSaveDict['cameraID'] = cameraID
            mongoDBSaveDict['cameraIP'] = cameraIP
            mongoDBSaveDict['timeStamp'] = datetimeobj
            mongoDBSaveDict['imageurl'] = imgURL
            mongoDBSaveDict['type'] = eventType
            mongoDBSaveDict['severity'] = severity
            mongoDBSaveDict['data'] = data
            mongoDBSaveDict["location"] = location
            mongoDBSaveDict['newUIData'] = {"event": ["disconnection"]}
            mongoDBSaveDict['alertID'] = alertID
            self.collection.insert_one(mongoDBSaveDict)
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            infoTolog = "ERROR! "+str(exc_type)+" " + \
                str(fname)+" " + str(exc_tb.tb_lineno)
            print(infoTolog)


class RedisUtil:
    def __init__(self, params: dict):
        self.params = params
        host = str(params["host"])
        db = int(params["db"])
        password = str(params["password"])
        port = int(params["port"])
        try:
            pool = redis.ConnectionPool(
                host=host, port=port, db=db, password=password)
            self.rObj = redis.Redis(connection_pool=pool)
        except Exception as e:
            raise Exception("Could not connect to redis instance")

    def forward(self, eventType, eventMessage, severity, datetimestr, imgURL, alertid, location, cameraID, cameraIP, geoJson):
        try:
            jsonData = {}
            jsonData["cameraId"] = cameraID
            jsonData['cameraIP'] = cameraIP
            jsonData["timeStamp"] = datetimestr
            jsonData["severity"] = severity
            jsonData["geoCoordinates"] = {"latitude": str(
                geoJson["lat"]), "longitude": str(geoJson["long"])}
            jsonData["imageurl"] = imgURL
            jsonData["objectDetails"] = {"event": "disconnection"}
            jsonData["alertMessage"] = eventMessage
            jsonData["eventType"] = eventType
            jsonData['alertId'] = alertid
            key = "cameraTamperingAlert"
            self.rObj.rpush(key, json.dumps(jsonData))
            self.rObj.rpush(key+"_iccc", json.dumps(jsonData))
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            infoTolog = "ERROR! "+str(exc_type)+" " + \
                str(fname)+" " + str(exc_tb.tb_lineno)
            print(infoTolog)


def sendAlert(eventType, eventMessage, severity, location, timestamp, cameraID, cameraIP, minioParams, mongoParams, redisParams, geoJson, alertURL, data):
    try:
        datetimestr, datetimeobj = timestampToDateTime(timestamp)
        datetimestr_ = datetimestr.replace(" ", "").replace(":", "_")
        location = location.replace(".", "-").replace("/", "-").replace(" ", "-")
        alertImagePath = "{}{}.jpg".format(location, datetimestr_)

        # let us create a blank image. As we have associated Alert with last frame recieved.
        # since in gst we may not get last frame from camera, let us create a blank image

        ret, msg, alertid = getAlertID(eventType, alertURL)
        if not ret:
            raise Exception(msg)

        # upload to object storage
        fileName = "alert.jpg"
        objName = eventType.lower()+'alerts/'+location+"/"+alertImagePath.split("/")[-1]

        bucketName = 'alerts'
        minioClient = MinioUploader(minioParams)
        ret, errMsg, imgURL = minioClient.forward(
            bucketName, objName, fileName, deltaDays=5, content_type="image/jpeg")

        # write to DB
        monogoObj = MongoDBUtil(mongoParams)
        monogoObj.forward(eventType, eventMessage, severity,
                          datetimeobj, imgURL, alertid, location, cameraID, cameraIP, data)

        # push to redis
        redisObj = RedisUtil(redisParams)
        redisObj.forward(eventType, eventMessage, severity, datetimestr,
                         imgURL, alertid, location, cameraID, cameraIP, geoJson)
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        infoTolog = "ERROR! "+str(exc_type)+" " + \
            str(fname)+" " + str(exc_tb.tb_lineno)
        print(infoTolog)


ALERTIDURL = "http://192.168.111.113:7002/getalertid"
minioParams = {
    "endpoint": "192.168.111.111:9000",
    "access_key": "access_key",
    "secret_key": "secrete_key",
    "MINIOURLREPLACEMENT": ""
}
mongoParams = {
    "host": "mongodb://user:password@192.168.111.113:27017/?authSource=admin",
    "dbname": "CHAND_ALERT",
    "collection": "alerts"
}
redisParams = {
    "host": "192.168.111.112",
    "port": 6379,
    "password": "Friends123#",
    "db": 0
}

geoJson = {"lat": 0.00, "long": 0.00}


def push_alert(**kwargs):
    sendAlert(
        kwargs.get("eventType", "cameraTamperingDet"),
        kwargs.get("eventMessage", "Camera Tampering detected"),
        kwargs.get("severity", "high"),
        kwargs.get("location", "unknown"),
        kwargs.get("timestamp", time.time()),
        kwargs.get("cameraID", "unknown"),
        kwargs.get("cameraIP", "unknown"),
        kwargs.get("minioParams", minioParams),
		kwargs.get("mongoParams", mongoParams),
		kwargs.get("redisParams", redisParams),
        kwargs.get("geoJson", geoJson),
		kwargs.get("alertURL", ALERTIDURL)
    )


if __name__ == "__main__":

    eventType = "cameraTamperingDet"
    eventMessage = "Camera Tampering detected"
    severity = "high"  # should expose to user for setting this as parameter source_parameter
    location = "park_entry_camera"
    timestamp = time.time()
    cameraID = "24_244"
    cameraIP = cameraID  # if possible get ip of the camera

    sendAlert(eventType, eventMessage, severity, location, timestamp,
              cameraID, cameraIP, minioParams, mongoParams, redisParams, ALERTIDURL)

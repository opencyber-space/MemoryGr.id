from logging import log
import redis
import time
import json

from .aios_logger import AIOSLogger, ErrorSeverity
from .env import Envs
from .push_alert import AlertPusher

def start_listening(logger: AIOSLogger):

    sourceHistory = {}

    # load all the envs
    env = Envs()

    logger.info(
        action="start_up",
        message="Starting up stream_alerts",
        extras={}
    )

    # listen to Redis in a while loop, so it will recover when failed:
    while True:
        try:
            logger.save_as_status = env.enable_status_update
            # connect to the Redis instance:
            connection = redis.Redis(
                host=env.redis_host,
                port=env.redis_port,
                password=env.redis_password,
                db=env.redis_db
            )

            ping_result = connection.ping()
            if not ping_result:
                r_h, r_p = env.redis_host, env.redis_port
                raise Exception("Failed to ping redis at {}:{}, {}".format(
                    r_h, r_p, "retrying after {}s".format(
                        env.conenct_retry_interval
                    )
                ))

            logger.info(
                action="stream_alerts_event_loop",
                message="Connected to Redis, listening for events",
                extras={}
            )

            # pinged, now wait for the tasks:
            while True:
                _, data = connection.brpop(env.redis_queue_name)
                if not data:
                   logger.warning(
                       action="stream_alerts_pop",
                       message="Popped empty item, continue",
                       extras={}
                   )
                   continue

                data = data.decode("utf-8")
                logger.info(
                    action="stream_alerts_pop",
                    message="Popped alert from queue",
                    extras={}
                )

                data = json.loads(data)

                if 'action' in data and data['action'] == "sendAlert":

                    if not 'sourceID' in data:
                        logger.error(
                            action="stream_alert_pop",
                            severity=ErrorSeverity.HIGH,
                            message="stream alerts service failed because of {}".format(e),
                            exception=e,
                            extras={}
                        )
                    else:
                        alertsPusher = AlertPusher(env, data['sourceID'], logger)

                        extraData = sourceHistory.get(data['sourceID'], {}) 

                        alertsPusher.push(extraData)

                        if data['sourceID'] in sourceHistory:
                            logger.info(
                                action="low_fps",
                                message="low fps received for source, sourceID={}".format(data['sourceID']),
                                extras={
                                    "sourceID": data['sourceID'],
                                    "extraData": extraData
                                }
                            )
    
                            del sourceHistory[data['sourceID']]
                        else:
                            logger.info(
                                action="camera_disconnect",
                                message="camera got disconnected, sourceID={}".format(data['sourceID']),
                                extras={
                                    "sourceID": data['sourceID']
                                }
                            )
                        

                elif 'action' in data and data['action'] == 'fpsReport':

                    sourceId = data.get('sourceID')
                    if not sourceId:
                        logger.error(
                            action="stream_alert_pop",
                            severity=ErrorSeverity.HIGH,
                            message="stream alerts service failed because of {}".format(e),
                            exception=e,
                            extras={}
                        )
                    else:

                        sourceHistory[sourceId] = data.get('fpsData')

                else:
                    logger.warning(
                        action="stream_alerts_pop",
                        message="Got invalid action",
                        extras={}
                    )
               

        except Exception as e:
            time.sleep(env.redis_connect_retry_interval)
            logger.error(
                action="stream_alert_pop",
                severity=ErrorSeverity.HIGH,
                message="stream alerts service failed because of {}".format(e),
                exception=e,
                extras={}
            )
